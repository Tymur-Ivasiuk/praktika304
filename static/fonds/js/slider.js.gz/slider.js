$(document).ready(function() {
    $('.quotes_slider').slick({
        dots: true,
        autoplay: true,
        autoplaySpeed: 3000,
        speed: 500,
    });
});